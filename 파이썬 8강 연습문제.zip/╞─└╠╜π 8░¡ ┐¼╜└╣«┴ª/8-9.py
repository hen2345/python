import math
num=float(input("실수 : "))
print(num,":",math.ceil(num))
print(num,":",math.floor(num))
print(num,":",math.trunc(num))
